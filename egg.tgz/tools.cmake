# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(kingfisher-3 src/kingfisher-3.cpp)
set_property(TARGET kingfisher-3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kingfisher-3 lionss pthread)

add_executable(LbfgsTwoloop src/LbfgsTwoloop.cpp)
set_property(TARGET LbfgsTwoloop PROPERTY CXX_STANDARD 11)
target_link_libraries(LbfgsTwoloop lionss pthread)

add_executable(labelSmooth src/labelSmooth.cpp)
set_property(TARGET labelSmooth PROPERTY CXX_STANDARD 11)
target_link_libraries(labelSmooth lionss pthread)

add_executable(quickcheckGen src/quickcheckGen.cpp)
set_property(TARGET quickcheckGen PROPERTY CXX_STANDARD 11)
target_link_libraries(quickcheckGen lionss pthread)

add_executable(ssao_kernel src/ssao_kernel.cpp)
set_property(TARGET ssao_kernel PROPERTY CXX_STANDARD 11)
target_link_libraries(ssao_kernel lionss pthread)

add_executable(flintlock src/flintlock.cpp)
set_property(TARGET flintlock PROPERTY CXX_STANDARD 11)
target_link_libraries(flintlock lionss pthread)

add_executable(btree-vacuum src/btree-vacuum.cpp)
set_property(TARGET btree-vacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(btree-vacuum lionss pthread)

add_executable(tinwhistle src/tinwhistle.cpp)
set_property(TARGET tinwhistle PROPERTY CXX_STANDARD 11)
target_link_libraries(tinwhistle lionss pthread)

add_executable(matterCommission src/matterCommission.cpp)
set_property(TARGET matterCommission PROPERTY CXX_STANDARD 11)
target_link_libraries(matterCommission lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(HaskellStrictness src/HaskellStrictness.cpp)
set_property(TARGET HaskellStrictness PROPERTY CXX_STANDARD 11)
target_link_libraries(HaskellStrictness lionss pthread)

add_executable(VkDescriptor src/VkDescriptor.cpp)
set_property(TARGET VkDescriptor PROPERTY CXX_STANDARD 11)
target_link_libraries(VkDescriptor lionss pthread)

add_executable(tiering-osr src/tiering-osr.cpp)
set_property(TARGET tiering-osr PROPERTY CXX_STANDARD 11)
target_link_libraries(tiering-osr lionss pthread)

add_executable(openapi_lint src/openapi_lint.cpp)
set_property(TARGET openapi_lint PROPERTY CXX_STANDARD 11)
target_link_libraries(openapi_lint lionss pthread)

add_executable(harbor_light src/harbor_light.cpp)
set_property(TARGET harbor_light PROPERTY CXX_STANDARD 11)
target_link_libraries(harbor_light lionss pthread)

add_executable(opticalFlow src/opticalFlow.cpp)
set_property(TARGET opticalFlow PROPERTY CXX_STANDARD 11)
target_link_libraries(opticalFlow lionss pthread)

add_executable(cobalt-run src/cobalt-run.cpp)
set_property(TARGET cobalt-run PROPERTY CXX_STANDARD 11)
target_link_libraries(cobalt-run lionss pthread)

add_executable(ssaDestruct src/ssaDestruct.cpp)
set_property(TARGET ssaDestruct PROPERTY CXX_STANDARD 11)
target_link_libraries(ssaDestruct lionss pthread)

add_executable(glassfern src/glassfern.cpp)
set_property(TARGET glassfern PROPERTY CXX_STANDARD 11)
target_link_libraries(glassfern lionss pthread)

add_executable(md_nvt_300k src/md_nvt_300k.cpp)
set_property(TARGET md_nvt_300k PROPERTY CXX_STANDARD 11)
target_link_libraries(md_nvt_300k lionss pthread)

add_executable(mux9 src/mux9.cpp)
set_property(TARGET mux9 PROPERTY CXX_STANDARD 11)
target_link_libraries(mux9 lionss pthread)

add_executable(voxel-remesh src/voxel-remesh.cpp)
set_property(TARGET voxel-remesh PROPERTY CXX_STANDARD 11)
target_link_libraries(voxel-remesh lionss pthread)

add_executable(tickresample src/tickresample.cpp)
set_property(TARGET tickresample PROPERTY CXX_STANDARD 11)
target_link_libraries(tickresample lionss pthread)

add_executable(anf-lower src/anf-lower.cpp)
set_property(TARGET anf-lower PROPERTY CXX_STANDARD 11)
target_link_libraries(anf-lower lionss pthread)

add_executable(undistortmap src/undistortmap.cpp)
set_property(TARGET undistortmap PROPERTY CXX_STANDARD 11)
target_link_libraries(undistortmap lionss pthread)

add_executable(cmaessigma src/cmaessigma.cpp)
set_property(TARGET cmaessigma PROPERTY CXX_STANDARD 11)
target_link_libraries(cmaessigma lionss pthread)

add_executable(WaveletDenoise src/WaveletDenoise.cpp)
set_property(TARGET WaveletDenoise PROPERTY CXX_STANDARD 11)
target_link_libraries(WaveletDenoise lionss pthread)

add_executable(aftermathDump src/aftermathDump.cpp)
set_property(TARGET aftermathDump PROPERTY CXX_STANDARD 11)
target_link_libraries(aftermathDump lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(hpa_scaleup src/hpa_scaleup.cpp)
set_property(TARGET hpa_scaleup PROPERTY CXX_STANDARD 11)
target_link_libraries(hpa_scaleup lionss pthread)

