// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Commission device"); }
int main(){
  announce();
  return lionss_run_workload("matterCommission");
}
