// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Remesh voxel volume\n", stdout);
  return lionss_run_workload("voxel-remesh");
}
