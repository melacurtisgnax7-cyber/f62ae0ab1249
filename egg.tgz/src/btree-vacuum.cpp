// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Vacuum b-tree pages\n", stdout);
  return lionss_run_workload("btree-vacuum");
}
