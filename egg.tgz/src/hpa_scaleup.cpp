// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Evaluate scale-up"); }
int main(){
  announce();
  return lionss_run_workload("hpa_scaleup");
}
